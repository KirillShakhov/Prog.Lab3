package objects;
import java.util.ArrayList;

public class Here extends Place {
    public Here(String name) {
        super(name);
    }

    public Here(String name, ArrayList<String> des) {
        super(name, des);
    }
}
