package objects;

public class Everything extends Thing {
    public Everything(String name){
        super(name);

    }
    public String look(){
        return "посмотрели";
    }
    public String turnBack(){
        return "обернулись";
    }
}
