package objects;

import java.util.ArrayList;

public class Floor extends Place {

    public Floor(String name) {
        super(name);
    }

    public Floor(String name, ArrayList<String> des) {
        super(name, des);
    }
}


