package objects;

public class Light extends Thing {
    public Light(String name) {
        super(name);
    }
}
