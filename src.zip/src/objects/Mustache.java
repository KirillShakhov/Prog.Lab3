package objects;

import java.util.ArrayList;

public class Mustache extends Thing {

    public Mustache(String name) {
        super(name);
    }

    public Mustache(String name, ArrayList<String> des) {
        super(name, des);
    }
}

